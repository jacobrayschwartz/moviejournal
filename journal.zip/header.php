<!DOCTYPE html>
<html lang="en">
<head>
	
<!--
	AUTHOR(S): Ralph Parkison, Jake Schwartz, Corey Sizemore 
-->

	<meta charset="utf-8" />
	<title>Movie Diary Application</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Awesome movie diary application.">
    <meta name="keywords" content="">
    <meta name="copyright" content="">
    <meta name="author" content="Ralph Parkison, Jake Schwartz, Corey Sizemore">
	
<!-- STYLESHEETS -->
	<link rel="stylesheet" href="css/cornerstone_v2.0.css" />
	<link rel="stylesheet" href="css/styles.css" />

<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
	
</head>
<body>